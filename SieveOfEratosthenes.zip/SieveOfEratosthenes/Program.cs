﻿using System;
using System.Collections.Generic;

namespace SieveOfEratosthenes
{
    class Program
    {
        static public List<int> normalNumbers = new List<int> { 1 };
        static void Main(string[] args)
        {
            int startingPrime = 2;
            int maxPrime = 10000000;

            while (startingPrime < maxPrime)
            {
                Console.WriteLine(startingPrime.ToString());
                CalculateMultiples(startingPrime);
                startingPrime++;
                while(normalNumbers.Contains(startingPrime))
                {
                    startingPrime++;
                }
            }
        }
        static public void CalculateMultiples(int value)
        {
            int calculatedNumber = 0;
            int calculatingNumber = 2;
            int maxNumber = 100000000; //Falls die Prime jemals über diese Zahl kommt, werden all Nummern angezeigt. 

            while (calculatedNumber < maxNumber)
            {
                calculatedNumber = calculatingNumber * value;
                normalNumbers.Add(calculatedNumber);
                calculatingNumber++;
            }
        }
    }
}
